#ifndef EVENTNAME_H
#define EVENTNAME_H


class EventName
{
public:
    static const int FIRST = 0;
    static const int LAST = 1;
    static const int VERTICAL = 2;
};

#endif // EVENTNAME_H
