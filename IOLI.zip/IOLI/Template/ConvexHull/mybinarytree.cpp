#include "mybinarytree.h"

MyBinaryTree::MyBinaryTree()
{
    this->tree = nullptr;
}

void MyBinaryTree::insertKey(float new_key) {
    if (this->tree == nullptr) {

    }
}
