#include "myevent.h"

MyEvent::MyEvent() {

}

MyEvent::MyEvent(EventName n, QPointF p, MySegment s) {
    this->name = n;
    this->point = p;
    this->segment = s;
}

EventName MyEvent::getEvent() {
    return this->name;
}

QPointF MyEvent::getPoint() {
    return this->point;
}

MySegment MyEvent::getSegment() {
    return this->segment;
}
