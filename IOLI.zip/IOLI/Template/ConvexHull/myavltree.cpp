#include "myavltree.h"

MyAVLTree::MyAVLTree()
{
    this->tree = NULL;
}

MyAVLTree::MyAVLTree(MyNode n) {
    this->tree = &n;
}


void MyAVLTree::insertKey(MyEvent new_key) {

    MyNode * n1 = tree;
    MyNode * n2 = tree;
    float y = new_key.getPoint().y();
    while (n2 != NULL) {
        n1 = n2;
        if (n1->key.getPoint().y() > y) {
            n2 = n1->left;
        } else {
            n2 = n1->right;
        }
    }

    if (n1 == NULL) {
        tree = new MyNode();
        tree->key = new_key;
        tree->left = NULL;
        tree->right = NULL;

    } else if (n1->key.getPoint().y() > y) {
        n1->left = new MyNode(new_key);
    } else {
        n1->right = new MyNode(new_key);
    }

}


void MyAVLTree::deleteKey(MyEvent old_key) {
    MyNode * n1 = tree;
    MyNode * n2 = tree;
    MySegment old_segment = old_key.getSegment();
    int left = 0;
    float old_y = old_segment.getFirstPoint().y();
    if (n2 != NULL) {
        while ( ! n2->key.getSegment().isEqual(old_segment) ) {
            n1 = n2;
            if (n1->key.getPoint().y() > old_y) {
                n2 = n1->left;
                left = 1;
            } else {
                n2 = n1->right;
                left = 0;
            }
        }

        if (n2->left == NULL && n2->right == NULL) {
            if (left) {
                n1->left = NULL;
            } else {
                n1->right = NULL;
            }
        } else if (n2->left == NULL) {
            if (left) {
                n1->left = n2->left;
            } else {
                n1->right = n2->left;
            }
        } else if (n2->right == NULL) {
            if (left) {
                n1->left = n2->right;
            } else {
                n1->right = n2->right;
            }
        } else {

        }


    }
}


void MyAVLTree::range_search(float start, float end) {

}


MyAVLTree MyAVLTree::getSuccessor() {
    return *this->tree;
}


MyAVLTree MyAVLTree::getMin() {
    return *this->tree;
}


MyNode * MyAVLTree::getTree() {
    return tree;
}
