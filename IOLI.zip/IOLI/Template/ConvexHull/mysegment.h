#ifndef MYSEGMENT_H
#define MYSEGMENT_H
#include <QFuture>
#include <math.h>

/* For horizontal segments : first point = left point ; last point = right point
 * For vertical segments : first point = upper point ; last point = lower point
*/
class MySegment
{
public:
    MySegment();
    MySegment(QPointF p1, QPointF p2);
    QPointF getFirstPoint();
    QPointF getLastPoint();
    //1 if the segment is vertical, 0 if horizontal
    int isVertical();
    int isEqual(MySegment s);
private:
    QPointF firstPoint;
    QPointF lastPoint;
    static constexpr float EPSILON = 0.0001;
};

#endif // MYSEGMENT_H
