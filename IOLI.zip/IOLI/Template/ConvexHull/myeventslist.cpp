#include "myeventslist.h"

MyEventsList::MyEventsList()
{
    // allocation of memory
    this->tab = (MyEvent * ) malloc(MyEventsList::FIRST_SIZE * sizeof(MyEvent));

    // no element in the array
    this->events_number = 0;

    this->current_size = MyEventsList::FIRST_SIZE;
}


void MyEventsList::addEvent(MySegment s) {


    // reallocate memory if the array is full
    if (this->events_number >= this->current_size -1) {

        int new_size = this->current_size + MyEventsList::FIRST_SIZE;
        MyEvent *new_tab = (MyEvent*) realloc (this->tab, new_size * sizeof(MyEvent));

            if (new_tab != NULL) {

              this->tab = new_tab;

              // modificate the size of the memory available
              this->current_size = new_size;

            }

            // if realloc did not work
            else {
              free (new_tab);
              puts ("Error (re)allocating memory");
              exit (1);
            }
    }


    // add the event at this end
    if (s.isVertical()) {
        this->tab[this->events_number] = MyEvent(EventName::VERTICAL, s.getFirstPoint(), s);
        this->events_number++;
    } else {
        this->tab[this->events_number] = MyEvent(EventName::FIRST, s.getFirstPoint(), s);
        this->tab[this->events_number +1] = MyEvent(EventName::LAST, s.getLastPoint(), s);
        this->events_number += 2;
    }

}


MyEvent MyEventsList::getEvent(int i) {
    if ( (0 <= i) && (i < this->events_number)) {
        return this->tab[i];
    } else {
        perror("Index out of range");
        exit (1);
    }
}

int MyEventsList::getEventsNumber() {
    return this->events_number;
}

void MyEventsList::mergeSort() {
    int n = this->events_number;
    if (n > 1) {
        mergeSortIndex(0, n - 1);
    }
}




void MyEventsList::merge(int start1, int start2, int end1, int end2) {
    int k1 = start1;
    int k2 = start2;
    int k = 0;
    MyEvent * new_tab = (MyEvent *) malloc((end2 - start1 + 1) * sizeof(MyEvent));
    while (k1 <= end1 || k2 <= end2 ) {

        // we already put all the elements of tab1
        if (k1 > end1) {
            new_tab[k] = this->tab[k2];

            k2++;
            k++;


        // we already put all the elements of tab2
        } else if (k2 > end2) {
            new_tab[k] = this->tab[k1];
            k1++;
            k++;

        // the next element of tab1 is smaller than the next element of tab2
        } else if (this->tab[k1].getPoint().x() < this->tab[k2].getPoint().x()) {
            new_tab[k] = this->tab[k1];
            k1++;
            k++;

        // the next element of tab1 and the next element of tab2 have the same x
        } else if (this->tab[k1].getPoint().x() < this->tab[k2].getPoint().x()) {

            // choosing regarding to the event
            // we suppose lines are not sharing more than one point

            // we need to put the beginning of a line firt
            if (this->tab[k1].getEvent() == EventName::FIRST) {
                new_tab[k] = this->tab[k1];
                k1++;
                k++;
            } else if (this->tab[k2].getEvent() == EventName::FIRST) {
                new_tab[k] = this->tab[k2];
                k2++;
                k++;

            // then a vertical line
            } else if (this->tab[k1].getEvent() == EventName::VERTICAL) {
                new_tab[k] = this->tab[k1];
                k1++;
                k++;
            } else if (this->tab[k2].getEvent() == EventName::VERTICAL) {
                new_tab[k] = this->tab[k2];
                k2++;
                k++;

            // then impossible
            } else {
                new_tab[k] = this->tab[k1];
                k1++;
                k++;
            }

        // the next element of tab2 is smaller than the next element of tab1
        }  else {
            new_tab[k] = this->tab[k2];

            k2++;
            k++;
        }

    }
    for (int i = 0 ; i < k ; i++) {
        this->tab[start1 + i] = new_tab[i];
    }

    free(new_tab);

}



void MyEventsList::mergeSortIndex(int start, int end) {
    if (end != start) {
        int middle = (start + end) / 2;
        mergeSortIndex(start, middle);
        mergeSortIndex(middle +1, end);
        merge(start, middle +1, middle, end);
    }
}
