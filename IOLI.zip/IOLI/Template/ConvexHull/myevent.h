#ifndef MYEVENT_H
#define MYEVENT_H

#include <QFuture>
#include "mysegment.h"

enum class EventName { FIRST, LAST, VERTICAL };

class MyEvent
{
public:
    MyEvent();
    MyEvent(EventName n, QPointF p, MySegment s);
    EventName getEvent();
    QPointF getPoint();
    MySegment getSegment();
private:
    EventName name;
    QPointF point;
    MySegment segment;

};

#endif // MYEVENT_H
