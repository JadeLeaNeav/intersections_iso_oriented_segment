// Convexe Hülle
// (c) Georg Umlauf, 2015

#include "glwidget.h"
#include <QtGui>
#include <GL/glu.h>
#include "mainwindow.h"




GLWidget::GLWidget(QWidget *parent) : QGLWidget(parent)
{	
    isFirstPoint = 0;
    this->segmentsList = new MySegmentsList();
    this->eventsList = new MyEventsList();
    this->intersections = new MyPointsList();
    this->activeSegments = new QMap<float, MyEvent>();
}

GLWidget::~GLWidget()
{
}

void GLWidget::paintGL()
{
    // clear
    glClear(GL_COLOR_BUFFER_BIT);

    // Koordinatensystem
    glColor3f(0.5,0.5,0.5);
    glBegin(GL_LINES);
    glVertex2f(-1.0, 0.0);
    glVertex2f( 1.0, 0.0);
    glVertex2f( 0.0,-1.0);
    glVertex2f( 0.0, 1.0);
    glEnd();

    //draw lines
    glBegin(GL_LINES);
    glColor3f(0,0,1);
    MySegment s(QPointF(0, 0), QPointF(1, 1));
    for (int segment = 0; segment < segmentsList->getSegmentsNumber() ; segment++) {
        s = segmentsList->getSegment(segment);
        glVertex2f(s.getFirstPoint().x(), s.getFirstPoint().y());
        glVertex2f(s.getLastPoint().x(), s.getLastPoint().y());
    }
    glEnd();

    //draw dots
    glBegin(GL_POINTS);
    glColor3f(1,0,0);
    for (int segment = 0; segment < segmentsList->getSegmentsNumber() ; segment++) {
        s = segmentsList->getSegment(segment);
        glVertex2f(s.getFirstPoint().x(), s.getFirstPoint().y());
        glVertex2f(s.getLastPoint().x(), s.getLastPoint().y());
    }
    glEnd();
    //draw intersections
    glBegin(GL_POINTS);
    glColor3f(0,1,0);
    QPointF p;
    for (int inter = 0; inter < intersections->getPointsNumber() ; inter++) {
        p = intersections->getPoint(inter);
        glVertex2f(p.x(), p.y());
        glVertex2f(p.x(), p.y());
    }
    glEnd();

//    for (int ent = 0; ent < eventsList->getEventsNumber() ; ent++) {
//        MyEvent e = eventsList->getEvent(ent);
//        qDebug() << e.getPoint();
//    }
//    qDebug() << "fin";
}


void GLWidget::initializeGL()
{
    resizeGL(width(),height());
}

void GLWidget::resizeGL(int width, int height)
{
    aspectx=1.0;
    aspecty=1.0;
    if (width>height) aspectx = float(width) /height;
    else              aspecty = float(height)/ width;
    glViewport    (0,0,width,height);
    glMatrixMode  (GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D    (-aspectx,aspectx,-aspecty,aspecty);
    glMatrixMode  (GL_MODELVIEW);
    glLoadIdentity();
}

QPointF GLWidget::transformPosition(QPoint p)
{
    return QPointF( (2.0*p.x()/ width() - 1.0)*aspectx,
		           -(2.0*p.y()/height() - 1.0)*aspecty);
}

void GLWidget::keyPressEvent(QKeyEvent * event)
{
	switch (event->key()) {
	default:
		break;
	}
	update();
}

void GLWidget::mousePressEvent(QMouseEvent *event)
{
	QPointF posF = transformPosition(event->pos());
	if (event->buttons() & Qt::LeftButton ) {

        if (isFirstPoint) {
            isFirstPoint = 0;
            segmentsList->addSegment(MySegment(firstPoint, posF));
            eventsList->addEvent(MySegment(firstPoint, posF));
            iiols();
        } else {
            isFirstPoint = 1;
            firstPoint = posF;
        }
	}
    update(); 
}

void GLWidget::iiols() {
    eventsList->mergeSort();
    QMap<float, MyEvent> aS;
    MyEvent currentEvent;
    MyPointsList * pointList = new MyPointsList();
    int nbEvents = eventsList->getEventsNumber();
    QMap<float, MyEvent>::iterator i;
    for (int event = 0 ; event < nbEvents ; event++) {
        currentEvent = eventsList->getEvent(event);
        if (currentEvent.getEvent() == EventName::FIRST) {
            aS.insert(currentEvent.getPoint().y(), currentEvent);
        } else if (currentEvent.getEvent() == EventName::LAST) {
            aS.remove(currentEvent.getPoint().y());
        } else {
            float x = currentEvent.getSegment().getLastPoint().x();
            float current_y;
            float yl = currentEvent.getSegment().getLastPoint().y();
            float yu = currentEvent.getSegment().getFirstPoint().y();
            for (i = aS.lowerBound(yl); i != aS.upperBound(yu); ++i) {
                current_y = i.key();
                pointList->addPoint(QPointF(x, current_y));
            }

        }
    }
    this->intersections = pointList;
//    qDebug() << "debut";
//    for (int m= 0 ; m < eventsList->getEventsNumber() ; m++) {
//        qDebug() << eventsList->getEvent(m).getPoint().x();
//    }
//    ActiveSegmentsList activeSegments;
//    MyEvent currentEvent;
//    MyPointsList * pointList = new MyPointsList();
//    int nbEvents = eventsList->getEventsNumber();
//    for (int event = 0 ; event < nbEvents ; event++) {
//        currentEvent = eventsList->getEvent(event);
//        if (currentEvent.getEvent() == EventName::FIRST) {
//            activeSegments.addEvent(currentEvent);
//        } else if (currentEvent.getEvent() == EventName::LAST) {
//            activeSegments.deleteEvent(currentEvent);
//        } else {
//            float x = currentEvent.getSegment().getLastPoint().x();
//            float current_y;
//            float yl = currentEvent.getSegment().getLastPoint().y();
//            float yu = currentEvent.getSegment().getFirstPoint().y();
//            for (int i = 0 ; i < activeSegments.getEventsNumber() ; i++) {
//                current_y = activeSegments.getEvent(i).getPoint().y();
//                if (yl <= current_y && current_y <= yu) {
//                    pointList->addPoint(QPointF(x, current_y));
//                }
//            }
//        }
//    }
//    this->intersections = pointList;

}

void GLWidget::printSegment(MySegment s) {
    qDebug() << "segment : " << s.getFirstPoint() << " ; " << s.getLastPoint();
}

void GLWidget::printTree(MyAVLTree * tree) {
    if (tree != NULL) {
        if (tree->getTree()->getLeft() != NULL) {
            MyAVLTree left(*tree->getTree()->getLeft());
            printTree(&left);
        }

        qDebug() << tree->getTree()->getKey().getPoint().y();
        if (tree->getTree()->getRight() != NULL) {
        MyAVLTree right(*tree->getTree()->getRight());
        printTree(&right);
        }
    }

}
