#include "eventname.h"

EventName::EventName()
{

}
