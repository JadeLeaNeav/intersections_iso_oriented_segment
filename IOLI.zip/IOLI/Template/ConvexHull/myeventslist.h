#ifndef MYEVENTSLIST_H
#define MYEVENTSLIST_H

#include "myevent.h"

class MyEventsList
{
public:
    MyEventsList();
    void addEvent(MySegment s);
    MyEvent getEvent(int i);
    int getEventsNumber();
    void mergeSort();

private:

    void merge(int start1, int start2, int end1, int end2);

    // recursive function sorting an array from start index to end
    void mergeSortIndex(int start, int end);

    // constante used to modifiy the size of the memory available for the array
    static const int FIRST_SIZE = 100;

    // array of points
    MyEvent * tab;

    // size of the memory available
    int current_size;

    // number of points in the array
    int events_number;
};

#endif // MYEVENTSLIST_H
