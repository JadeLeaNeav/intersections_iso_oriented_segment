#include "mysegmentslist.h"

MySegmentsList::MySegmentsList()
{
    // allocation of memory
    this->tab = (MySegment * ) malloc(MySegmentsList::FIRST_SIZE * sizeof(MySegment));

    // no element in the array
    this->segments_number = 0;

    this->current_size = MySegmentsList::FIRST_SIZE;
}

void MySegmentsList::addSegment(MySegment s) {

    // reallocate memory if the array is full
    if (this->segments_number == this->current_size) {

        int new_size = this->current_size + MySegmentsList::FIRST_SIZE;
        MySegment *new_tab = (MySegment*) realloc (this->tab, new_size * sizeof(MySegment));

            if (new_tab != NULL) {

              this->tab = new_tab;

              // modificate the size of the memory available
              this->current_size = new_size;

            }

            // if realloc did not work
            else {
              free (new_tab);
              puts ("Error (re)allocating memory");
              exit (1);
            }
    }

    // add the point at this end
    this->tab[this->segments_number] = s;
    this->segments_number++;
}
MySegment MySegmentsList::getSegment(int i) {
    if ( (0 <= i) && (i < this->segments_number)) {
        return this->tab[i];
    } else {
        perror("Index out of range");
        exit (1);
    }

}
int MySegmentsList::getSegmentsNumber() {
    return this->segments_number;
}
