#include "activesegmentslist.h"

ActiveSegmentsList::ActiveSegmentsList()
{
    // allocation of memory
    this->tab = (MyEvent * ) malloc(ActiveSegmentsList::FIRST_SIZE * sizeof(MyEvent));

    // no element in the array
    this->events_number = 0;

    this->current_size = ActiveSegmentsList::FIRST_SIZE;
}

void ActiveSegmentsList::addEvent(MyEvent new_event) {
    // reallocate memory if the array is full
    if (this->events_number == this->current_size) {

        int new_size = this->current_size + ActiveSegmentsList::FIRST_SIZE;
        MyEvent *new_tab = (MyEvent*) realloc (this->tab, new_size * sizeof(MyEvent));

            if (new_tab != NULL) {

              this->tab = new_tab;

              // modificate the size of the memory available
              this->current_size = new_size;

            }

            // if realloc did not work
            else {
              free (new_tab);
              puts ("Error (re)allocating memory");
              exit (1);
            }
    }

    // add the point at this end
    this->tab[this->events_number] = new_event;
    this->events_number++;

}

void ActiveSegmentsList::deleteEvent(MyEvent old_event) {
    int k = 0;
    MyEvent e = this->tab[0];

    // should stop before being out of the array
    while (!e.getSegment().isEqual(old_event.getSegment())) {
        k++;
        e = this->tab[k];
    }
    if (k == this->events_number -1) {
        this->events_number--;
    } else {
        for (int i = k ; i < this->events_number -1; i++ ) {
            this->tab[k] = this->tab[k+1];
        }
        this->events_number--;
    }

}

MyEvent ActiveSegmentsList::getEvent(int k) {
    if ( (0 <= k) && (k < this->events_number)) {
        return this->tab[k];
    } else {
        perror("Index out of range");
        exit (1);
    }
}


int ActiveSegmentsList::getEventsNumber() {
    return this->events_number;
}
