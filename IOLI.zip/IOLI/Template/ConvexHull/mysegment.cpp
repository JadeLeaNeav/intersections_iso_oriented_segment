#include "mysegment.h"

MySegment::MySegment() {

}

MySegment::MySegment(QPointF p1, QPointF p2)
{
    float x1 = p1.x();
    float x2 = p2.x();
    float dx = fabs(x1 - x2);

    float y1 = p1.y();
    float y2 = p2.y();
    float dy = fabs(y1 - y2);

    QPointF first;
    QPointF last;

    if (dx < dy) {
        if (y1 < y2) {
            first = QPointF(x1, y2);
            last = QPointF(x1, y1);
        } else {
            first = QPointF(x1, y1);
            last = QPointF(x1, y2);
        }
    } else {
        if (x1 < x2) {
            first = QPointF(x1, y1);
            last = QPointF(x2, y1);
        } else {
            first = QPointF(x2, y1);
            last = QPointF(x1, y1);
        }
    }

    this->firstPoint = first;
    this->lastPoint = last;

}
QPointF MySegment::getFirstPoint() {
    return QPointF(this->firstPoint.x(), this->firstPoint.y());
}
QPointF MySegment::getLastPoint() {
    return QPointF(this->lastPoint.x(), this->lastPoint.y());
}

//1 if the segment is vertical, 0 if horizontal
int MySegment::isVertical() {
    if (this->firstPoint.x() == this->lastPoint.x()) {
        return 1;
    } else {
        return 0;
    }
}



int MySegment::isEqual(MySegment s) {
    return ( (this->firstPoint.x() - s.firstPoint.x()) < EPSILON ) && (this->firstPoint.y() - s.firstPoint.y() && (this->lastPoint.x() - s.lastPoint.x()) < EPSILON ) && (this->lastPoint.y() - s.lastPoint.y());
}
