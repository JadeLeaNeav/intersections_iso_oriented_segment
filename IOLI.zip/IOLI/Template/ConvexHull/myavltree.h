#ifndef MYAVLTREE_H
#define MYAVLTREE_H

#include "mynode.h"

class MyAVLTree
{
public:
    MyAVLTree();
    MyAVLTree(MyNode n);
    void insertKey(MyEvent new_key);
    void deleteKey(MyEvent old_key);
    void range_search(float start, float end);
    MyAVLTree getSuccessor();
    MyNode * getTree();
private:
    MyNode *tree;
    MyAVLTree getMin();
};

#endif // MYAVLTREE_H
