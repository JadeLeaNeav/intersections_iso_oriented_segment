#ifndef MYNODE_H
#define MYNODE_H

#include "myevent.h"


class MyNode
{
public:
    MyNode();
    MyNode(MyEvent e);
    MyEvent getKey();
    MyNode * getLeft();
    MyNode * getRight();
private:
    MyNode *left;
    MyNode *right;
    MyEvent key;
    friend class MyAVLTree;
};

#endif // MYNODE_H
