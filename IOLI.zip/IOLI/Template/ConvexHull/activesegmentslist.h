#ifndef ACTIVESEGMENTSLIST_H
#define ACTIVESEGMENTSLIST_H

#include "myevent.h"


class ActiveSegmentsList
{
public:
    ActiveSegmentsList();
    void addEvent(MyEvent new_event);
    void deleteEvent(MyEvent old_event);
    MyEvent getEvent(int k);
    int getEventsNumber();

private:
    // constante used to modifiy the size of the memory available for the array
    static const int FIRST_SIZE = 100;

    // array of points
    MyEvent * tab;

    // size of the memory available
    int current_size;

    // number of points in the array
    int events_number;
};

#endif // ACTIVESEGMENTSLIST_H
