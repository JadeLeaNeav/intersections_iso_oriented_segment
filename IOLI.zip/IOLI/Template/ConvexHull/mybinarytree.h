#ifndef MYBINARYTREE_H
#define MYBINARYTREE_H
#include "mynode.h"


class MyBinaryTree
{
public:
    MyBinaryTree();
    void insertKey(float new_key);
    void deleteKey(float old_key);
    void range_search(float start, float end);
    MyBinaryTree getSuccessor();
private:
    MyNode *tree;
    MyBinaryTree getMin();
};

#endif // MYBINARYTREE_H
