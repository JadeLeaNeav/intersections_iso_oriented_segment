// Convexe Hlle
// 
// Widget fr Interaktion und Kontrolle 
//
// (c) Georg Umlauf, 2014

#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>
#include <QFuture>
#include "mysegmentslist.h"
#include "myeventslist.h"
#include "mypointslist.h"
#include "myavltree.h"
#include "activesegmentslist.h"
#include <QMap>

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    GLWidget                  (QWidget *parent=0);
    ~GLWidget                 ();
signals: 
	void continueRequest      ();
protected:
    void paintGL              ();
    void initializeGL         ();
    void resizeGL             (int width, int height);
    void keyPressEvent        (QKeyEvent   *event);
    void mousePressEvent      (QMouseEvent *event);
private:
    void printSegment(MySegment s);
    QPointF transformPosition (QPoint p);
    void iiols();
	double  aspectx, aspecty;
    QPointF firstPoint;
    int isFirstPoint;
    MySegmentsList * segmentsList;
    MyEventsList * eventsList;
    MyPointsList * intersections;
    QMap<float, MyEvent> * activeSegments;
    void printTree(MyAVLTree * tree);

};



#endif // GLWIDGET_H
