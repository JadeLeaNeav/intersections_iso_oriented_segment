#ifndef MYSEGMENTSLIST_H
#define MYSEGMENTSLIST_H

#include "mysegment.h"

class MySegmentsList
{
public:
    MySegmentsList();
    void addSegment(MySegment s);
    MySegment getSegment(int i);
    int getSegmentsNumber();

private:
    // constante used to modifiy the size of the memory available for the array
    static const int FIRST_SIZE = 100;

    // array of points
    MySegment * tab;

    // size of the memory available
    int current_size;

    // number of points in the array
    int segments_number;
};

#endif // MYSEGMENTSLIST_H
