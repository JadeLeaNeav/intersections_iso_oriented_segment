#include "mynode.h"

MyNode::MyNode()
{
}

MyNode::MyNode(MyEvent e) {
    this->key = e;
    this->left = NULL;
    this->right = NULL;
}

MyEvent MyNode::getKey() {
    return this->key;
}
MyNode * MyNode::getLeft(){
    return this->left;
}
MyNode * MyNode::getRight() {
    return this->right;
}
